enum MenuPage{
  None,
  Backboard,
  Invoice,
  Message,
  Reservation,
  Schedule,
  Condominium
}