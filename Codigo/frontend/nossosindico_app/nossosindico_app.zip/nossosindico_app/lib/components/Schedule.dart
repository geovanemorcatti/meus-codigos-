import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'dart:ui' as ui;
import 'package:nossosindico_app/modules/SizeConfig.dart';
import 'package:nossosindico_app/modules/Evento.dart';

class Schedule extends StatefulWidget {
  const Schedule();
  @override
  State<Schedule> createState() => _ScheduleState();
}

class _ScheduleState extends State<Schedule> {
  List<Evento> listaEvento = [];

  Future<List<Evento>> _getListEvento() async {
    listaEvento = [
      new Evento("01/12/1989", "asfa sfd asfas"),
      new Evento("18/05/2022", "asfa sfd asfas"),
      new Evento("19/05/2022", "asfa sfd asfas"),
      new Evento("20/05/2022", "asfa sfd asfas"),
      new Evento("21/05/2022", "asfa sfd asfas"),
      new Evento("22/05/2022", "asfa sfd asfas"),
      new Evento("23/05/2022", "asfa sfd asfas"),
      new Evento("24/05/2022", "asfa sfd asfas"),
      new Evento("25/05/2022", "asfa sfd asfas"),
      new Evento("26/05/2022", "asfa sfd asfas"),
      new Evento("27/05/2022", "asfa sfd asfas"),
      new Evento("28/05/2022", "asfa sfd asfas"),
      new Evento("29/05/2022", "asfa sfd asfas"),
    ];
    return [];
    /*var Url = 'http://localhost:8080/listFatura';
    final response = await http.post(Uri.parse(Url),
        headers: <String, String>{"Content-Type": "application/json"},
        body: jsonEncode(<String, String>{"cond": condominio.id.toString()}));
    print(response.statusCode);
    print(response.body);
    if (response.statusCode == 200) {
      List<dynamic> parsedMapJson = json.decode(response.body);
      List<Fatura> fatura = [];
      for (int i = 0; i < parsedMapJson.length; i++) {
        Fatura fatura = Fatura.fromJson(parsedMapJson[i]);
        listaFatura.add(fatura);
        print(condominio);
      }
      return listaFatura;
    } else {
      throw Exception('DEU erro imbecil');
    }*/
  }

  String weekString(int week) {
    String resp = "";
    switch (week) {
      case 1:
        resp = "Segunda";
        break;
      case 2:
        resp = "Terça";
        break;
      case 3:
        resp = "Quarta";
        break;
      case 4:
        resp = "Quinta";
        break;
      case 5:
        resp = "Sexta";
        break;
      case 6:
        resp = "Sabado";
        break;
      case 7:
        resp = "Domingo";
        break;
      default:
        resp = "Que coisa";
    }
    return resp;
  }

  @override
  Widget build(BuildContext context) {
    SizeConfig().init(context);
    return Align(
        alignment: Alignment.topCenter,
        child: Container(
            margin: const EdgeInsets.only(left: 20.0, right: 20.0),
            width: SizeConfig.safeBlockHorizontal! * 85 < SizeConfig.screenWidth!
                ? SizeConfig.safeBlockHorizontal! * 85
                : SizeConfig.screenWidth!,
            child: Column(children: [
              SizedBox(
                height: SizeConfig.safeBlockVertical! * 100 - 160,
                child: SingleChildScrollView(
                  child: FutureBuilder<List<Evento>>(
                      future: _getListEvento(),
                      builder: (context, snapshot) {
                        if (snapshot.hasData) {
                          return ListView.separated(
                            shrinkWrap: true,
                            padding: const EdgeInsets.all(20),
                            itemCount: listaEvento.length,
                            separatorBuilder:
                                (BuildContext context, int index) =>
                            const Divider(),
                            itemBuilder: (BuildContext context, int index) {
                              return Row(children: [
                                SizedBox(
                                  width: 80,
                                  child: Column(
                                    children: [
                                      Text(
                                        DateFormat("dd/MM").format(
                                            DateFormat('d/M/y').parse(
                                                listaEvento[index].data)),
                                        style: const TextStyle(
                                            fontWeight: FontWeight.bold,
                                            fontFamily: 'FavoritPro'),
                                      ),
                                      Text(
                                        weekString(DateFormat('d/M/y')
                                            .parse(listaEvento[index].data)
                                            .weekday),
                                      ),
                                    ],
                                  ),
                                ),
                                Text(
                                  listaEvento[index].descricao,
                                ),
                              ]);
                            },
                          );
                        } else if (snapshot.hasError) {
                          return Text("${snapshot.error}");
                        }
                        return const CircularProgressIndicator();
                      }),
                ),
              ),
            ])));
  }
}