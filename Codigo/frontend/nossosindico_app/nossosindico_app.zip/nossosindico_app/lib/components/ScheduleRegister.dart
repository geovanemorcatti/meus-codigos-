import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:nossosindico_app/modules/SizeConfig.dart';
import 'package:nossosindico_app/modules/Evento.dart';
import 'package:nossosindico_app/modules/FieldValidator.dart';
import 'package:http/http.dart' as http;

class ScheduleRegister extends StatefulWidget {
  const ScheduleRegister();
  @override
  State<ScheduleRegister> createState() => _ScheduleRegisterState();
}

class _ScheduleRegisterState extends State<ScheduleRegister> {
  final _formKey = GlobalKey<FormState>();

  final TextEditingController _controladorNome = TextEditingController(),
      _controladorData = TextEditingController();

  void fetchPost(Evento evento) async {
    var Url = 'http://localhost:8080/cadastroEvento';
    var response = await http.post(Uri.parse(Url),
        headers: <String, String>{"Content-Type": "application/json"},
        body: jsonEncode(<String, String>{
          "data": evento.data,
          "descricao": evento.descricao,
        }));
    print(response.statusCode);
    Navigator.pop(context);
  }

  void onPressed() {
    if (_formKey.currentState!.validate()) {
      Evento evento = Evento(_controladorData.text, _controladorNome.text,);
      fetchPost(evento);

      Navigator.pop(context);
    }
  }

  @override
  Widget build(BuildContext context) {
    SizeConfig().init(context);
    return Form(
      key: _formKey,
      child: Align(
        alignment: Alignment.center,
        child: Container(
          margin: const EdgeInsets.only(left: 20.0, right: 20.0),
          width: SizeConfig.safeBlockHorizontal! * 85 < SizeConfig.screenWidth!
              ? SizeConfig.safeBlockHorizontal! * 85
              : SizeConfig.screenWidth!,
          child: ListView(
            children: [
              Padding(
                padding: const EdgeInsets.fromLTRB(0, 8, 0, 8),
                child: TextFormField(
                  controller: _controladorData,
                  decoration: InputDecoration(
                      filled: true,
                      labelText: 'Data',
                      hintText: 'Data do Item',
                      fillColor: Colors.white,
                      hintStyle: TextStyle(color: Colors.blueGrey[100])),
                  keyboardType: TextInputType.datetime,
                  validator: FieldValidator.ValidarSenha,
                ),
              ),
              Padding(
                padding: const EdgeInsets.fromLTRB(0, 8, 0, 8),
                child: TextFormField(
                  controller: _controladorNome,
                  decoration: InputDecoration(
                      filled: true,
                      labelText: 'Nome',
                      hintText: 'Nome do Item',
                      fillColor: Colors.white,
                      hintStyle: TextStyle(color: Colors.blueGrey[100])),
                  keyboardType: TextInputType.name,
                  validator: FieldValidator.ValidarSenha,
                ),
              ),
              Padding(
                padding: const EdgeInsets.fromLTRB(0, 8, 0, 8),
                child: ElevatedButton(
                  child: const Align(
                    alignment: Alignment.center,
                    child: Padding(
                      padding: EdgeInsets.fromLTRB(0, 10, 0, 10),
                      child: Text(
                        'Sign-up',
                        style: TextStyle(
                            fontSize: 20.0, fontWeight: FontWeight.normal),
                        textAlign: TextAlign.center,
                      ),
                    ),
                  ),
                  onPressed: onPressed,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}