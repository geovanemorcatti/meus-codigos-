
import 'package:flutter/material.dart';

import '../screens/Layout.dart';
import '../screens/Login.dart';
import '../screens/painelSindico.dart';

class Reservation extends StatefulWidget {
  const Reservation();
  @override
  State<Reservation> createState() => _ReservationState();
}

class _ReservationState extends State<Reservation> {
  Widget floatingAction(BuildContext context) {
    if (usuario.sindico) {
      return FloatingActionButton(
        onPressed: () =>
        {
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (context) =>
              const Layout(
                body: PainelSindico(),
                accontIcon: false,
                menuIcon: false,
              ),
            ),
          )
        },
        child: Text("+"),
        backgroundColor: Colors.blue,
      );
    }
    return const Text("");
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      floatingActionButton: floatingAction(context),
    );
  }
}