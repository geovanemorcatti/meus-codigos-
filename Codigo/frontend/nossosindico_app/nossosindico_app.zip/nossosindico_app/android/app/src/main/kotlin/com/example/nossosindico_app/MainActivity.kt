package com.example.nossosindico_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}